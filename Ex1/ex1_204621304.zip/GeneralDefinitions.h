#ifndef EX1_GENERALDEFINITIONS_H
#define EX1_GENERALDEFINITIONS_H

enum class PieceType
{
    Rock, Paper, Scissors, Bomb, Joker, Flag
};

enum class PlayerID
{
    Player1, Player2
};

#endif //EX1_GENERALDEFINITIONS_H
